# essentially just an extension file
from .muppet import *