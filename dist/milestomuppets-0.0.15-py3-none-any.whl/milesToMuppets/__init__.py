# essentially just an extension file, makes it easier to access files as this runs on import
from .muppet import *