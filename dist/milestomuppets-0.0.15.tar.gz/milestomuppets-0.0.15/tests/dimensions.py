import os

width = os.get_terminal_size()[0]

print(width)